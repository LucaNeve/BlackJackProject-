package main.java.BlackJack.model;


public interface Bot {
    // Fa giocare i bot
    public void play(int nBot, Shoe shoe);
}
