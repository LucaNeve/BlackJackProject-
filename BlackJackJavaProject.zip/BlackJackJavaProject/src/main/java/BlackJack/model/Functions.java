package main.java.BlackJack.model;

public class Functions {

    private Hand hand;
    private boolean win;

    public Functions(Hand hand) {
        this.hand = hand;
    }

    public boolean getWin() {
        return this.win;
    }

    public void setWin(boolean win) {
        this.win = win;
    }

    public void hit(Shoe s) {
        this.hand.addCard(s);
    }

    public void stand(Hand hand) {
        this.hand = hand;
    }

    public Hand getHand() {
        this.hand.toString();
        return this.hand;
    }

    public void clearHand() {
        this.hand.resetHand();
    }

    public void setHand(Shoe s) {
        this.hand.generateHand(s);
    }

    public void setHandCards(Hand hand) {
        this.hand = hand;
    }
    

}
