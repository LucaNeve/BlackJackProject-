package main.java.BlackJack.model;

public class DealerImpl extends Functions implements Dealer {

    public DealerImpl(Hand dealerHand) {
        super(dealerHand);
    }

    public void play(Shoe shoe) {
        while (getHand().getHandValue() < 17) {
            this.getHand().addCard(shoe);
            System.out.println(
                    "Dealer hand: " + getHand().toString() + "value : " + this.getHand().getHandValue());
        }
        if (getHand().getHandValue() > 21) {
            System.out.println("\t\t# DEALER SBALLATO #");
        }
    }

    public String toString() {
        return "\n\tPlayer: Dealer" + "\nHand: " + getHand()
                + " value = " + getHand().getHandValue();
    }

}