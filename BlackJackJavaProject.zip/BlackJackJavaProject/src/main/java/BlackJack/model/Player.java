package main.java.BlackJack.model;

public interface Player {
    public String getName();

    public double getAmount();

    // Gestisce la giocata del double down
    public void doubleDown(double bet, Shoe shoe);

    public void setAmount(double bet);

    public void setBet(double bet);

    public double getBet();
}
