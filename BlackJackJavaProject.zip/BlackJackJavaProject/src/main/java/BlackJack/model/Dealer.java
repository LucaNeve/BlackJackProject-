package main.java.BlackJack.model;


public interface Dealer {
    // Fa giocare il dealer
    public void play(Shoe shoe);
}
