package main.java.BlackJack.model;

public class TableImpl implements Table {
    private static final double AMOUNT = 1000;
    private static final int NUM_DECK = 4;
    private final String playerName;
    private Shoe shoe;
    private PlayerImpl player;
    private PlayerImpl playerSplit;
    private PlayerImpl currentPlayer;
    private DealerImpl dealer;
    private BotImpl[] bots;
    private boolean gameOver;
    private boolean playerDone;
    private boolean dealerDone;
    private boolean botsdone;
    private boolean haveSplitted;
    private boolean splitDone;
    private boolean playerWin;
    private boolean tie;
    private int nBot;

    public TableImpl(String playerName, int nBot) {
        this.playerName = playerName;
        this.nBot = nBot;
        this.gameOver = false;

        // Creo la shoe
        this.shoe = new Shoe(NUM_DECK);

        // Creo il player e la sua mano
        this.player = new PlayerImpl(this.playerName, AMOUNT, new Hand());

        // Creo il player e la sua mano in caso di split
        this.playerSplit = new PlayerImpl(this.playerName + "Split", this.player.getBet(), new Hand());

        if (this.nBot != 0) {
            this.bots = new BotImpl[this.nBot];
            for (int i = 0; i < this.nBot; i++) {
                this.bots[i] = new BotImpl(new Hand());
            }
        }

        // Creo il dealer e la sua mano
        this.dealer = new DealerImpl(new Hand());
    }


    public boolean isBotsDone() {
        return this.botsdone;
    }

    public boolean isDealerDone() {
        return this.dealerDone;
    }

    public boolean isPlayerDone() {
        return this.playerDone;
    }

    public void setGameOver() {
        this.gameOver = true;
    }

    public boolean isPlayerWin() {
        return this.playerWin;
    }

    public boolean isTie() {
        return this.tie;
    }

    public boolean haveSplit() {
        return this.haveSplitted;
    }

    public boolean isSplitDone() {
        return this.splitDone;
    }

    public boolean isAmountOver() {
        if (this.player.getAmount() == 0) {
            this.gameOver = true;
        }
        return gameOver;
    }

    public PlayerImpl getPlayer() {
        return this.player;
    }

    public PlayerImpl getPlayerSplit() {
        return this.playerSplit;
    }

    public PlayerImpl getCurrentPlayer() {
        return this.currentPlayer;
    }

    public DealerImpl getDealer() {
        return this.dealer;
    }

    public void printPlayerAmount() {
        System.out.println("Il tuo saldo è: " + this.player.getAmount());
    }

    public boolean checkBetLimit(int bet) {
        return bet > this.player.getAmount();
    }

    // Setta la puntata e il saldo
    public void bet(int bet) {
        this.player.setBet(bet);
        this.player.setAmount(-(bet));
    }

    // Resetta le mani
    public void resetAllHands() {
        this.player.clearHand();
        this.dealer.clearHand();
        this.playerSplit.clearHand();
        if (this.nBot != 0)
            for (int i = 0; i < this.nBot; i++) {
                this.bots[i].clearHand();
            }
    }

    public void startGame() {
        this.setHandAndBoolean();
        this.printHand();
        this.checkBlackJack();
        this.controlPlayerDoneSplit();
        this.controlSplitShift();
    }

    // Inizializza le variabili booleane e setta le mani dei giocatori
    public void setHandAndBoolean() {
        this.playerDone = false;
        this.dealerDone = false;
        this.haveSplitted = false;
        this.splitDone = true;
        this.player.setHand(shoe);
        this.dealer.setHand(shoe);
        if (this.nBot != 0) {
            this.botsdone = false;
            for (int i = 0; i < this.nBot; i++) {
                this.bots[i].setHand(shoe);
            }
        }
    }


    // Stampa le mani dei giocatori
    public void printHand() {
        System.out.println("\n\tPlayer: Dealer" + "\nHand: [" + this.dealer.getHand().getFirstCard() +
                ", *CARTA COPERTA*] value = " + this.dealer.getHand().getFirstCard().getRank().getValue());
        if (this.nBot != 0)
            for (int i = 0; i < this.nBot; i++) {
                System.out.println("\nBot " + (i + 1) + " hand: " + this.bots[i].getHand() + " value : "
                        + this.bots[i].getHand().getHandValue() + "\n");
                if (this.bots[i].getHand().checkBlackJack()) {
                    System.out.println("\tIl BOT " + (i + 1) + " ha fatto BLACKJACK!\n");
                }
            }

        System.out.println(this.player);
    }

    // Controlla se il giocatore utente ha finito il turno
    public boolean controlShift() {
        return (!this.playerDone);
    }

    // Controlla se il giocatore utente ha finito il turno in una delle due mani
    // dello split
    private void controlPlayerDoneSplit() {
        if (this.player.getHand().getHandValue() == 21 && this.splitDone == true) {
            this.playerDone = true;
        }
        if (this.splitDone == false && this.playerSplit.getHand().getHandValue() == 21)
            this.splitDone = true;
    }

    // Controlla il turno delle mani splittate
    public void controlSplitShift() {
        if (!this.playerDone) {
            if (this.splitDone == false) {
                System.out.println("\n\tTocca alla mano splittata!\n");
                this.playerPlay(playerSplit);
            } else {
                System.out.println("\n\tTocca al player " + this.player.getName());
                this.playerPlay(player);
            }
        }
    }

    // Giocano i bot
    public void botPlay() {
        if (!this.botsdone && nBot > 0) {
            System.out.println("\n\tTocca ai bots!\n");
            for (int i = 0; i < this.nBot; i++) {
                System.out.println("\nBot " + (i + 1) + " hand: " + this.bots[i].getHand() + " value : "
                        + this.bots[i].getHand().getHandValue() + "\n");
                this.bots[i].play(i, shoe);
            }
            this.botsdone = true;

        }
    }

    // Gioca il dealer
    public void dealerPlay() {
        if (!this.dealerDone) {
            System.out.println("\n\tTocca al dealer!\n");
            System.out.println(dealer);

            this.dealer.play(shoe);
            this.dealerDone = true;
        }
    }

    public void checkShoe() {
        this.shoe.checkShoe();
    }

    // Controllo Blackjack
    private void checkBlackJack() {
        if (this.player.getHand().checkBlackJack()) {
            this.player.setAmount((this.player.getBet() / 2));
            System.out.println("\tHai fatto BlackJack!!!\n");
            if (this.splitDone == true)
                this.playerDone = true;
        }

        if (this.splitDone == false) {
            if (this.playerSplit.getHand().checkBlackJack()) {
                this.player.setAmount((this.player.getBet() / 2) );
                System.out.println("\n\tHai fatto BlackJack NELLO SPLIT!!!\n");
                this.splitDone = true;
            }
        }
    }

    public boolean isDoubleDownPossible() {
        return ((this.player.getAmount() - this.player.getBet()) >= 0) && (this.player.getHand().getNumCardsInHand() == 2);
    }

    public boolean isSplitPossible() {
        return this.currentPlayer.getHand().splitPossible() && this.haveSplitted == false
                && (this.player.getAmount() - this.player.getBet()) >= 0;
    }

    // Gestisce le stampe delle mani del giocatore in caso di split
    public void playerPlay(PlayerImpl p) {
        this.currentPlayer = p;
        this.checkBlackJack();

        if (this.splitDone == false) {
            System.out.println("\nLe tue mani:");
            System.out.println(this.playerSplit);
            System.out.println(this.player);
            System.out.println("\n\nGioca la prima mano");
            System.out.println(this.currentPlayer);
        } else {
            if (this.haveSplitted == true) {
                System.out.println("\nLe tue mani:");
                System.out.println(this.playerSplit);
                System.out.println(this.player);
                System.out.println("\n\nGioca la seconda mano");
            }
            System.out.println(this.currentPlayer);
        }
    }

    public void hitPlay() {
        this.currentPlayer.hit(shoe);
        System.out.println(this.currentPlayer);
        this.checkLimit();
    }

    public void doubleDownPlay() {
        this.currentPlayer.doubleDown(this.player.getBet(), shoe);
        System.out.println(this.currentPlayer);
        this.checkLimit();
        if (this.splitDone == false) {
            this.splitDone = true;
        } else
            this.playerDone = true;
    }

    public void splitPlay() {
        this.playerSplit.getHand().add(player.getHand().getFirstCard());
        this.player.getHand().removeFirstCard();
        this.player.hit(shoe);
        this.playerSplit.hit(shoe);
        this.splitDone = false;
        this.haveSplitted = true;
        this.player.setAmount(-(this.player.getBet()));
    }

    public void stayPlay() {
        if (this.splitDone == false) {
            this.splitDone = true;
        } else
            this.playerDone = true;
    }

    private void checkLimit() {
        if (this.player.getHand().getHandValue() > 21) {
            System.out.println("\t\t\n#  Hai Sballato!  #\n");
            System.out.println(this.dealer);
            if (this.nBot != 0)
                for (int i = 0; i < this.nBot; i++) {
                    System.out.println("\nBot " + (i + 1) + "hand: " + this.bots[i].getHand() + " value : "
                            + this.bots[i].getHand().getHandValue() + "\n");
                }
            this.playerDone = true;
            if (this.haveSplitted == false)
                this.dealerDone = true;
            if (this.nBot != 0)
                this.botsdone = true;
        }

        if (this.splitDone == false) {
            if (this.playerSplit.getHand().getHandValue() > 21) {
                System.out.println("\t\t\n#  Hai Sballato!  #\n");
                this.splitDone = true;
            }
        }
    }

    public void decideWinner() {
        if (this.nBot != 0) {
            for (int i = 0; i < this.nBot; i++) {
                if ((this.bots[i].getHand().getHandValue() > this.dealer.getHand().getHandValue()
                        && this.bots[i].getHand().getHandValue() <= 21) ||
                        (this.bots[i].getHand().getHandValue() <= 21 && this.dealer.getHand().getHandValue() > 21)) {
                    System.out.println("\n\t\t# BOT " + (i + 1) + " HA VINTO #");
                } else if (this.bots[i].getHand().getHandValue() == this.dealer.getHand().getHandValue()) {

                    System.out.println("\n\t\t# BOT " + (i + 1) + " HA PAREGGIATO #");
                } else {
                    System.out.println("\n\t\t# BOT " + (i + 1) + " HA PERSO #");
                }
            }
        }

        if (this.haveSplitted == true) {
            if ((this.playerSplit.getHand().getHandValue() > this.dealer.getHand().getHandValue()
                    && this.playerSplit.getHand().getHandValue() <= 21) ||
                    (this.playerSplit.getHand().getHandValue() <= 21 && this.dealer.getHand().getHandValue() > 21)) {

                System.out.println("\n\t\t# HAI VINTO PRIMA MANO #");
                this.player.setAmount(this.player.getBet() * 2);

            } else if (this.playerSplit.getHand().getHandValue() == this.dealer.getHand().getHandValue()) {

                System.out.println("\n\t\t# PAREGGIO NELLA PRIMA MANO #");
                this.player.setAmount(this.player.getBet());

            } else {
                System.out.println("\n\t\t# HAI PERSO NELLA PRIMA MANO #");
            }

            if ((this.player.getHand().getHandValue() > this.dealer.getHand().getHandValue()
                    && this.player.getHand().getHandValue() <= 21) ||
                    (this.player.getHand().getHandValue() <= 21 && this.dealer.getHand().getHandValue() > 21)) {

                System.out.println("\n\t\t# HAI VINTO NELLA SECONDA MANO #");
                this.player.setAmount((this.player.getBet()) * 2);

            } else if (this.player.getHand().getHandValue() == this.dealer.getHand().getHandValue()) {

                System.out.println("\n\t\t# PAREGGIO NELLA SECONDA MANO #");
                this.player.setAmount(this.player.getBet());

            } else {
                System.out.println("\n\t\t# HAI PERSO NELLA SECONDA MANO #");
            }
        } else {

            if ((this.player.getHand().getHandValue() > this.dealer.getHand().getHandValue()
                    && this.player.getHand().getHandValue() <= 21) ||
                    (this.player.getHand().getHandValue() <= 21 && this.dealer.getHand().getHandValue() > 21)) {

                System.out.println("\n\t\t# HAI VINTO  #");
                this.player.setAmount(this.player.getBet() * 2);
                this.playerWin = true;
            } else if (this.player.getHand().getHandValue() == this.dealer.getHand().getHandValue()) {
                System.out.println("\n\t\t#   PAREGGIO   #");
                this.player.setAmount(this.player.getBet());
                this.tie = true;
            } else {
                System.out.println("\n\t\t#   HAI PERSO   #");
                this.playerWin = false;
            }
        }
    }
}