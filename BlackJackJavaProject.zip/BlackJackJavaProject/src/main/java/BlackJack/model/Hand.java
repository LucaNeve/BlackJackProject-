package main.java.BlackJack.model;

import java.util.*;

public class Hand {

    private ArrayList<Card> hand;
    private int handValue;

    public Hand() {
        this.hand = new ArrayList<Card>();
        this.handValue = 0;
    }

    public void generateHand(Shoe s) {
        for (int i = 0; i < 2; i++) {
            this.addCard(s);
        }
    }

    public void add(Card card) {
        this.hand.add(card);
    }

    public void addCard(Shoe s) {
        this.hand.add(s.pickCard());
    }

    public Card getFirstCard() {
        return this.hand.stream().findFirst().get();
    }

    public void removeFirstCard() {
        this.hand.remove(0);
    }

    public int getNumCardsInHand() {
        return this.hand.size();
    }

    public int getHandValue() {
        long acesNum = 0;
        this.handValue = 0;

        this.handValue = this.hand.stream().mapToInt(c -> c.getRank().getValue()).sum();
        acesNum = this.hand.stream().filter(c -> c.getRank().getValue() == 1).count();

        for (int i = 0; i < acesNum; i++) {
            if (this.handValue <= 11)
                this.handValue += 10;
        }

        return this.handValue;
    }

    public boolean checkBlackJack() {
        return (this.handValue == 21 && this.hand.size() == 2) ? true : false;
    }

    public void resetHand() {
        this.hand.clear();
    }

    public boolean splitPossible() {
        return (this.hand.size() == 2
                && (this.hand.get(0).getRank().getValue() == this.hand.get(1).getRank().getValue())) ? true : false;
    }
    
    public Card get(int i) {
    	return this.hand.get(i);
    }

    public String toString() {
        return this.hand.toString();
    }

}