package main.java.BlackJack.model;

public class PlayerImpl extends Functions implements Player {
    private double amount;
    private double bet;
    private String name;
    private boolean standing;

    public PlayerImpl(String name, double amount, Hand playerHand) {
        super(playerHand);
        this.name = name;
        this.amount = amount;
    }

    public String getName() {
        return this.name;
    }

    public double getAmount() {
        return this.amount;
    }

    public void doubleDown(double bet, Shoe shoe) {
        this.setAmount(-bet);
        this.setBet(bet * 2);
        this.hit(shoe);
    }

    public void setAmount(double bet) {
        this.amount += bet;
    }

    public void setBet(double bet) {
        this.bet = bet;
    }

    public double getBet() {
        return this.bet;
    }

    public boolean isStansding() {
        return this.standing;
    }

    public String toString() {
        return "\n\tPlayer: " + getName() + "\nAmount: " + getAmount() + "\tbet: " + getBet() + "\nHand: " + getHand()
                + " value  = " + getHand().getHandValue();
    }
}