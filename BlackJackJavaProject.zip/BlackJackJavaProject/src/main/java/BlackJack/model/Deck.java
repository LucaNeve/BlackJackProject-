package main.java.BlackJack.model;

import java.util.*;

public class Deck {

    private ArrayList<Card> deck;

    public Deck() {
        this.deck = new ArrayList<Card>();
        this.generateDeck();
    }

    public void generateDeck() {
        for (Card.Suit suit : Card.Suit.values()) {
            for (Card.Rank rank : Card.Rank.values()) {
                this.deck.add(new Card(rank, suit));
            }
        }
    }

    public Card getCard(int i){
        return this.deck.get(i);
    }

    public String toString() {
        String output = "";
        for (Card card : deck) {
            output += card;
            output += "\n";
        }

        return output;
    }

}