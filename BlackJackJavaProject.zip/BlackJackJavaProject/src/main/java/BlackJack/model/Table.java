package main.java.BlackJack.model;


public interface Table {

    // Controlla il game over
    public boolean isAmountOver();

    // Setta la puntata e il saldo
    public void bet(int bet);

    // Resetta tutte le mani
    public void resetAllHands();

    // Gestisce il flusso della partita effettuando diversi controlli richiamando
    // metodi specifici
    public void startGame();

    // Inizializza le variabili booleane e setta le mani dei giocatori
    public void setHandAndBoolean();

    // Stampa le mani dei giocatori
    public void printHand();

    // Giocano i bot
    public void botPlay();

    // Gioca il dealer
    public void dealerPlay();

    // Il giocatore chiama una carta
    public void hitPlay();

    // Il giocatore raddoppia la puntata e chiama una carta
    public void doubleDownPlay();

    // Il giocatore crea due mani separate
    public void splitPlay();

    // Il giocatore si ferma
    public void stayPlay();

    // Controllo del vincitore
    public void decideWinner();

}
