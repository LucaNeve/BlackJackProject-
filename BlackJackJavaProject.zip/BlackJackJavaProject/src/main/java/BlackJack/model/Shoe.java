package main.java.BlackJack.model;

import java.util.*;

public class Shoe {

    private ArrayList<Card> shoe;
    private ArrayList<Card> waste;
    private Deck[] decks;
     
    public Shoe(int numDeck) {
        this.shoe = new ArrayList<Card>();
        this.waste = new ArrayList<Card>();
        this.decks = new Deck[numDeck];
        for(int i = 0; i < decks.length; i++)
            this.decks[i] = new Deck();
        generateShoe();
        shuffleShoe();
    }

    public void generateShoe(){
        for(int i = 0; i < this.decks.length; i++){
            for(int j = 0; j < 52; j++){
                this.shoe.add(decks[i].getCard(j));
            }
        }
    }

    public int numCardInShoe(){
        return this.shoe.size();
    }


    private void shuffleShoe() {
        Collections.shuffle(this.shoe);
    }

    public Card pickCard() {

        Card card = this.shoe.remove(0);
        this.waste.add(card);
        return card;

    }

    public void checkShoe() {
        if (this.shoe.size() <= this.waste.size()) 
            resetShoe();
    }

    private void resetShoe() {
        this.shoe.addAll(this.waste);
        this.waste.clear();
        shuffleShoe();
        System.out.println("\nShoe ripristinata, ora la shoe ha di nuovo " + this.shoe.size() + " carte!\n");
    }

    public String toString() {
        String output = "";
        for (Card card : this.shoe) {
            output += card;
            output += "\n";
        }

        return output;
    }


}