package main.java.BlackJack.model;

public class Card {

    public enum Suit {
        Hearts, Diamonds, Spades, Clubs
    }

    public enum Rank {
        Ace(1),
        Two(2),
        Three(3),
        Four(4),
        Five(5),
        Six(6),
        Seven(7),
        Eight(8),
        Nine(9),
        Ten(10),
        Jack(10),
        Queen(10),
        King(10);

        int value;

        Rank(int value) {
            this.value = value;
        }

        public int getValue() {
            return this.value;
        }

    }

    private final Rank rank;
    private final Suit suit;

    public Card(Rank rank, Suit suit) {
        this.rank = rank;
        this.suit = suit;
    }

    public Rank getRank() {
        return this.rank;
    }

    public Suit getSuit() {
        return this.suit;
    }

    public String toString() {
    	return getRank() + "_of_" + getSuit();
    }

}