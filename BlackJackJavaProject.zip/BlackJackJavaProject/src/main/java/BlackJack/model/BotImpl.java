package main.java.BlackJack.model;

import java.util.Random;

public class BotImpl extends Functions implements Bot {
    private Random rnd;

    public BotImpl(Hand botHand) {
        super(botHand);
        this.rnd = new Random();
    }

    public void play(int nbot, Shoe shoe) {
        boolean result = true;
        int random;
        while (getHand().getHandValue() <= 15 && result == true) {
            //getHand().addCard(shoe);
            if(getHand().getHandValue() > 11){
                random = this.rnd.nextInt(2);
                if(random == 0){
                    System.out.println(random);
                    getHand().addCard(shoe);
                }
                result = false;
            }else{
                getHand().addCard(shoe);
            }

            System.out.println("Bot " + (nbot + 1) + " hand: " + getHand().toString() + " value : "
                    + getHand().getHandValue() + "\n");
        }
        if (getHand().getHandValue() > 21) {
            System.out.println("\n\t\t# BOT " + (nbot + 1) + " HA SBALLATO #\n");
        }
    }

    public boolean checkBotBlackJack() {
        if (getHand().getHandValue() == 21 && getHand().getNumCardsInHand() == 2)
            return true;
        else
            return false;
    }

    public String toString() {
        return "\n\tBOT " + " \nBOT Hand: " + getHand()
                + "\nWin? ->  " + getWin();
    }

}