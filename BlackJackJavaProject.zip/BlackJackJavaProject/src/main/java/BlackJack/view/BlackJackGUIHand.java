package main.java.BlackJack.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class BlackJackGUIHand extends JPanel implements ActionListener {
    private static final Color CARD_TABLE_GREEN = new Color(37, 93, 54);
    private static final Color TEXT_COLOR = new Color(230, 230, 230);
    private static final Dimension BUTTONS_DIMENSION = new Dimension(110, 25);
    
    // controller
    private GameManagerGUI controller;
    
    // cards panel components
    private JPanel cardsPanel;
    private JLabel handValueLabel;
    private JLabel handBetLabel;
    private JLabel handMessageLabel;
    private JButton hitButton;
    private JButton stayButton;
    private JButton splitButton;
    private JButton doubleDownButton;


    public BlackJackGUIHand(GameManagerGUI controller) {
        this.controller = controller;
        setupPanel();
        setupActionListeners();
    }
    
    
    private void setupActionListeners() {
        hitButton.addActionListener(this);
        stayButton.addActionListener(this);
        splitButton.addActionListener(this);
        doubleDownButton.addActionListener(this);
    }


    private void showChanges() {
        revalidate();
        repaint();
        setVisible(true);
    }


    private void setupPanel() {
        setBackground(CARD_TABLE_GREEN);
        setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        cardsPanel = new JPanel();
        cardsPanel.setBackground(CARD_TABLE_GREEN);
        constraints.gridx = 0;
        constraints.gridy = 0;
        add(cardsPanel, constraints);
        handValueLabel = new JLabel();
        handValueLabel.setForeground(TEXT_COLOR);
        constraints.gridy = 1;
        add(handValueLabel, constraints);
        handBetLabel = new JLabel();
        handBetLabel.setForeground(TEXT_COLOR);
        constraints.gridy = 2;
        add(handBetLabel, constraints);
        handMessageLabel = new JLabel();
        handMessageLabel.setForeground(TEXT_COLOR);
        constraints.gridy = 3;
        add(handMessageLabel, constraints);
        JPanel hitstayButtonsPanel = new JPanel();
        hitstayButtonsPanel.setBackground(CARD_TABLE_GREEN);
        hitButton = new JButton("Hit");
        hitButton.setPreferredSize(BUTTONS_DIMENSION);
        hitButton.setEnabled(false);
        hitButton.setVisible(false);
        stayButton = new JButton("Stand");
        stayButton.setPreferredSize(BUTTONS_DIMENSION);
        stayButton.setEnabled(false);
        stayButton.setVisible(false);
        hitstayButtonsPanel.add(hitButton);
        hitstayButtonsPanel.add(stayButton);
        constraints.gridy = 4;
        add(hitstayButtonsPanel, constraints);
        JPanel yesNoButtonsPanel = new JPanel();
        yesNoButtonsPanel.setBackground(CARD_TABLE_GREEN);
        splitButton = new JButton("Split Pairs");
        splitButton.setPreferredSize(BUTTONS_DIMENSION);
        splitButton.setEnabled(false);
        splitButton.setVisible(false);
        doubleDownButton = new JButton("Double Down");
        doubleDownButton.setPreferredSize(BUTTONS_DIMENSION);
        doubleDownButton.setEnabled(false);
        doubleDownButton.setVisible(false);
        yesNoButtonsPanel.add(splitButton);
        yesNoButtonsPanel.add(doubleDownButton);
        constraints.gridy = 5;
        add(yesNoButtonsPanel, constraints);
    }
    
    
    public void addCard(JLabel cardLabel) {
        cardsPanel.add(cardLabel);
        showChanges();
    }


    public void setHandValueLabel(int i) {
        handValueLabel.setText("Valore mano: " + i);
        showChanges();
    }


    public void setHandBet(String bet) {
        handBetLabel.setText("Puntata: $" + bet);
        showChanges();
    }


    public void setHandMessageLabel(String message) {
        handMessageLabel.setText(message);
        showChanges();
    }
    

    public void turnError() {
        setHandMessageLabel("ERRORE");
        showChanges();
    }

    
    public void removeCard(JLabel cardLabel) {
        cardsPanel.remove(cardLabel);
        showChanges();
    }
    
    public void reset() {
    	cardsPanel.removeAll();
    }
    
    
    public void doubleDownSuccess() {
        setHandMessageLabel("La tua puntata per questa mano è stata raddoppiata.");
        showChanges();
    }


    public void bust() {
        setHandMessageLabel("Hai Sballato.");
        showChanges();
    }
    
    
    public void enableHitStand() {
        enableHitButton(true);
        enableStayButton(true);
        showChanges();
    }


    public void enableSplit() {
        enableSplitButton(true);
        showChanges();
    }
    
    
    public void disableSplit() {
        enableSplitButton(false);
        showChanges();
    }


    public void enableDoubleDown() {
        enableDoubleDownButton(true);
        showChanges();
    }
    
    
    public void disableDoubleDown() {
        enableDoubleDownButton(false);
        showChanges();
    }


    public void enableHitButton(Boolean b) {
        hitButton.setEnabled(b);
        hitButton.setVisible(b);
        showChanges();
    }


    public void enableStayButton(Boolean b) {
        stayButton.setEnabled(b);
        stayButton.setVisible(b);
        showChanges();
    }


    public void enableSplitButton(Boolean b) {
        splitButton.setEnabled(b);
        splitButton.setVisible(b);
        showChanges();
    }
    

    public void enableDoubleDownButton(Boolean b) {
        doubleDownButton.setEnabled(b);
        doubleDownButton.setVisible(b);
        showChanges();
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        Object target = e.getSource();
        
        if(target == hitButton) {
        	controller.table.hitPlay();
        	controller.getMessage(hitButton.getText());
        	controller.GetplayGame();
        	controller.PlayerDone();
        	
        } else if (target == stayButton) {
        	controller.table.stayPlay();
        	controller.getMessage(stayButton.getText());
        	controller.GetplayGame();
        	controller.PlayerDone();
        	
        } else if (target == splitButton) {
        	controller.table.splitPlay();
        	controller.getMessage(splitButton.getText());
        	controller.GetplayGame();
        	controller.PlayerDone();
        	
        } else if (target == doubleDownButton) {
        	controller.table.doubleDownPlay();
        	controller.getMessage(hitButton.getText());
        	controller.GetplayGame();
        	controller.PlayerDone();
        	
        }
    }
}
