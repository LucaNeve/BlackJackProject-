package main.java.BlackJack.view;

//import java.util.Scanner;

public class GameManagerGUI {
	protected TableImplGUI table;
    private int bet;
    private String playerName;
    private String clientMessage = null;
    private String choice = null;
    private boolean receivedChoice = false;
	private boolean betNotNumeric = false;
    private BlackJackGUIView view;
    private BlackJackGUIHand hand;
    private BlackJackGUIHand splithand;
    
    public GameManagerGUI(String playerName) {
    	this.playerName = playerName;
    	this.view = new BlackJackGUIView(this); 
    	this.hand = new BlackJackGUIHand(this); 
    	this.splithand = new BlackJackGUIHand(this);
    	this.setUpGame();
    }
	

	private void setUpGame() {
        this.table = new TableImplGUI("DANI", this.view, this.hand, this.splithand);
        this.Welcome(this.playerName);
        this.setGame();
	}

	
    public void waiter() {
    	try {
  		  Thread.sleep(3000);
  		} catch (InterruptedException e) {
  		  Thread.currentThread().interrupt();
  		}
    }
    
    
    public void Welcome(String playerName) {
    	this.view.showWelcomePanel(playerName);
    	this.waiter();
    }
    
    
    public void resetAll() {
    	this.view.reset();
        this.hand.reset();
        this.view.resetPlayerHand(this.hand);
        this.table.resetAllHands();
    	this.table.hand.setHandMessageLabel("");
    }
    
    
    public void setGame() {
    	this.resetAll();
        this.Start(this.playerName);  
        }
    
    public void Start(String playerName) {
    	this.view.showStartPanel();
        this.view.setStartLabel("Ciao " + playerName + ", Vuoi Giocare?");
    }

    
    public void GetStart() {
    	this.receivedChoice = false;
        do {
        	getChoice();
        } while(!this.receivedChoice);
        
        BetPanel();

    }
    
       
    public void BetPanel() {
        this.view.showBetPanel();
        this.view.setMinimumBetLabel(1);
        this.view.setBetMoneyLabel(this.table.player.getAmount());
    } 
    
    
    public void getBet() {
        this.receivedChoice = false;
        do {
        	this.bet = 0;
        	this.betNotNumeric = false;
        	getChoice();
        	try {                 
        		 this.bet = Integer.parseInt(this.choice);
            } catch (NumberFormatException e) {
                     this.betNotNumeric = true;                     
            }
        } while(!this.receivedChoice);
        
        TurnPanel();	
    }
        
        
    public void checkBet() {
        if (this.betNotNumeric) {
            this.view.betError("Valore inserito non valido, inserire un valore numerico intero");
            this.receivedChoice = false;
            BetPanel();
        }else if (this.bet > this.table.player.getAmount()) {
        	this.view.betError("Hai puntato troppo");
            this.receivedChoice = false;
            BetPanel();
        }else if (this.bet <= 0) {
            view.betError("La puntata deve essere > 0");
            this.receivedChoice = false;
            BetPanel();
        }
        	
    }
    
    
    public void TurnPanel() {
    	this.view.showTurnPanel();
    	this.resetViewHand();
    	this.table.showDeal();
    	this.view.enableDealButton(true);
    }
    
    
    public void getMessage(String Message) {
    	this.clientMessage = Message;
    }
    
    
    public String clientMessage() {
    	return this.clientMessage;
    }

    
    public void getChoice() {
    	while (!this.receivedChoice) {
    		String message;
            if ((message = clientMessage()) != null) {
                this.choice = message;
                this.receivedChoice = true;
            }
        }
    }
    
    
    public void resetViewHand() {
    	this.table.resetPlayerHand();
    	this.table.resetDealerHand();
    }
   

    public void playGame() {
        this.table.bet(this.bet);
    	this.resetViewHand();
    	this.view.setTurnMoneyLabel(this.table.player.getBet());
    	this.table.startGame();
        this.table.checkBlackJack();
        if(this.table.player.getHand().checkBlackJack() == true) {
        	PlayerDone();
        }
        this.table.shiftManagment();
        this.playControl();
    }
    

    public void GetplayGame() {
        this.table.shiftManagment();
    	this.table.controlSplit();
    	this.playControl();
    	this.receivedChoice = false;
        do {
        	getChoice();
        } while(!this.receivedChoice);
        
    }
    
    
    public void PlayerDone() {

    	if(!this.table.isPlayerDone()) {
              this.checkPlayerDone();
         }
         if(this.table.isPlayerDone()) {
              GetplayGame();
         }
         if(this.table.isSplitDone() == true) {
     		this.table.disableSplitHandButton();
         }
    }

    
    public void checkPlayerDone() {
        	this.table.hand.setHandMessageLabel("");
        	this.view.setTurnMoneyLabel(this.table.player.getBet());
            this.table.disableHandButton();
            this.table.dealerPlay();
            this.table.decideWinner();
            this.table.checkShoe();
            if(this.table.isGameOver()) {
            	this.view.showContinuePlayingPanel();
            	this.view.gameOver();	
            }
            this.view.setMessageLabel("Vuoi continuare a giocare?");
            this.view.enableYesButton(true);
            this.view.enableNoButton(true);

    }
    
    public void playControl() {
    	if(this.table.haveSplit() == true) {
        	if(this.table.isPlayerDone()  == true){
        		this.table.enableSplitHitStandButton();
                if (this.table.DoubleDownButton()) {
                    this.table.enableSplitDoubleDownButton();
                }else {
                	this.table.disableSplitDoubleDownButton();
                }
                if (this.table.isSplitPossible()) {
                    this.table.enableSplitSplitButton();
                }else {
                	this.table.disableSplitButton();
                }
        	}
    	}
    	
    	
    	if(this.table.isPlayerDone() == true){
    		this.table.enableHitStandButton();
            if (this.table.DoubleDownButton()) {
                this.table.enableDoubleDownButton();
            }else {
            	this.table.disableDoubleDownButton();
            }
            if (this.table.isSplitPossible()) {
                this.table.enableSplitButton();
            }else {
            	this.table.disableSplitButton();
            }
    	if(this.table.isSplitDone() == false) {
    		this.table.disableHandButton();
    	}
    	if(this.table.isSplitDone() == true) {
    		this.table.disableSplitHandButton();
    	}
    	}
    }

}
