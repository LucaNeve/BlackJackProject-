package main.java.BlackJack.view;


import javax.imageio.ImageIO;
import javax.swing.*;

import main.java.BlackJack.model.DealerImpl;
import main.java.BlackJack.model.PlayerImpl;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Scanner;


public class BlackJackGUIView extends JFrame implements ActionListener {
    private static final Dimension FRAME_START_DIMENSION = new Dimension(1000, 700);
    private static final Dimension DEALER_HAND_PANEL_DIMENSION = new Dimension(930, 170);
    private static final Dimension PLAYER_HANDS_PANEL_DIMENSION = new Dimension(930, 265);
    private static final Dimension BUTTONS_DIMENSION = new Dimension(110, 25);
    private static final int BET_FIELD_SIZE = 8;
    private static final Color CARD_TABLE_GREEN = new Color(37, 93, 54);
    private static final Color TEXT_COLOR = new Color(230, 230, 230);
    private static final Float WELCOME_LABEL_SIZE = 30.0f;
    private static final Float BET_LABEL_SIZE = 14.0f;
    private static final Float HANDS_LABEL_SIZE = 18.0f;
    private static final Float NAME_LABEL_SIZE = 16.0f;
    private static final Float START_LABEL_SIZE = 16.0f;
    
    // controller
    public GameManagerGUI controller;

    // welcome panel components
    private JLabel nameLabel;

    // start panel components
    private JLabel startLabel;
    private JButton playButton;
    private JButton exitButton;
    
    // bet panel components
    private JLabel minimumBetLabel;
    public JTextField betField;
    public JButton betButton;
    private JLabel betMoneyLabel;
    private JLabel betMessageLabel;

    // turn panel components
    private JPanel dealerHandPanel;
    private JLabel dealerHandValueLabel;
    private JLabel dealerMessageLabel;
    private JPanel playerHandsPanel;
    private JLabel messageLabel;
    private JButton yesButton;
    private JButton noButton;
    private JLabel blackjackLabel;
    private JLabel turnMoneyLabel;
    private JButton dealButton;

    // continue playing panel components
    private JLabel continuePlayingMessageLabel;
    
  
    private enum PanelNames {
        WELCOMEPANEL, STARTPANEL, BETPANEL, TURNPANEL, CONTINUEPLAYINGPANEL
    }

    
    public BlackJackGUIView(GameManagerGUI controller) {
    	this.controller = controller;
    	setupWindowListener();
        setupFrame();
        createPanels();
        setupActionListeners();
    }


    private void setupWindowListener() {
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int response = JOptionPane.showConfirmDialog(null, "Sei sicuro si voler uscire?", null, JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (response == JOptionPane.YES_OPTION) {
                    quitGame();
                }
            }
        });
    }
    
    
    public void quitGame() {
        System.exit(0);
    }


    private void setupFrame() {
        setTitle("BlackJack");
        setMinimumSize(FRAME_START_DIMENSION);
        setResizable(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLayout(new CardLayout());
        showChanges();
    }


    private void createPanels() {
        createWelcomePanel();
    	createStartPanel();
        createBetPanel();
        createTurnPanel();
        createContinuePlayingPanel();
    }


    private void setupActionListeners() {
    	playButton.addActionListener(this);
    	exitButton.addActionListener(this);
    	dealButton.addActionListener(this);
        betField.addActionListener(this);
        betButton.addActionListener(this);
        yesButton.addActionListener(this);
        noButton.addActionListener(this);
    }


    private void showChanges() {
        revalidate();
        repaint();
        setVisible(true);
    }


    private void createWelcomePanel() {
        JPanel welcomePanel = new JPanel(new GridBagLayout());
        welcomePanel.setBackground(CARD_TABLE_GREEN);
        GridBagConstraints constraints = new GridBagConstraints();
        JLabel welcomeLabel = new JLabel("Benvenuto al BlackJack");
        welcomeLabel.setForeground(TEXT_COLOR);
        welcomeLabel.setFont(welcomeLabel.getFont().deriveFont(WELCOME_LABEL_SIZE));
        constraints.insets = new Insets(10, 0, 10, 20);
        constraints.gridx = 0;
        constraints.gridy = 0;
        welcomePanel.add(welcomeLabel, constraints);
        nameLabel = new JLabel();
        nameLabel.setForeground(TEXT_COLOR);
        nameLabel.setFont(nameLabel.getFont().deriveFont(NAME_LABEL_SIZE));
        nameLabel.setVisible(true);
        constraints.gridy = 1;
        welcomePanel.add(nameLabel, constraints);
        add(welcomePanel, PanelNames.WELCOMEPANEL.toString());
    }
    
    
    private void createStartPanel() {
        JPanel startPanel = new JPanel(new GridBagLayout());
        startPanel.setBackground(CARD_TABLE_GREEN);
        GridBagConstraints constraints = new GridBagConstraints();
        startLabel = new JLabel();
        startLabel.setForeground(TEXT_COLOR);
        startLabel.setFont(startLabel.getFont().deriveFont(START_LABEL_SIZE));
        constraints.insets = new Insets(10, 0, 10, 20);
        constraints.gridx = 0;
        constraints.gridy = 0;
        startPanel.add(startLabel, constraints);
        playButton = new JButton("GIOCA");
        playButton.setPreferredSize(BUTTONS_DIMENSION);
        constraints.gridy = 1;
        startPanel.add(playButton, constraints);
        exitButton = new JButton("ESCI");
        exitButton.setPreferredSize(BUTTONS_DIMENSION);
        enableStartButton(false);
        constraints.gridy = 2;
        startPanel.add(exitButton, constraints);
        add(startPanel, PanelNames.STARTPANEL.toString());
    }
    
    
    public void setStartLabel(String message) {
    	startLabel.setText(message);
    }


    private void createBetPanel() {
        JPanel betPanel = new JPanel(new GridBagLayout());
        betPanel.setBackground(CARD_TABLE_GREEN);
        GridBagConstraints constraints = new GridBagConstraints();
        minimumBetLabel = new JLabel();
        minimumBetLabel.setForeground(TEXT_COLOR);
        minimumBetLabel.setFont(startLabel.getFont().deriveFont(BET_LABEL_SIZE));
        constraints.insets = new Insets(5, 0, 5, 5);
        constraints.gridx = 0;
        constraints.gridy = 0;
        betPanel.add(minimumBetLabel, constraints);
        betField = new JTextField(BET_FIELD_SIZE);
        constraints.gridy = 1;
        betPanel.add(betField, constraints);
        betMessageLabel = new JLabel();
        betMessageLabel.setForeground(TEXT_COLOR);
        constraints.gridy = 2;
        betPanel.add(betMessageLabel, constraints);
        betButton = new JButton("punta");
        betButton.setPreferredSize(BUTTONS_DIMENSION);
        constraints.gridy = 3;
        betPanel.add(betButton, constraints);
        betMoneyLabel = new JLabel();
        betMoneyLabel.setForeground(TEXT_COLOR);
        constraints.gridy = 4;
        betPanel.add(betMoneyLabel, constraints);
        add(betPanel, PanelNames.BETPANEL.toString());
    }


    public void setMinimumBetLabel(int minimumBet) {
        minimumBetLabel.setText("La puntata minima e' $" + minimumBet + ". Quanto vuoi puntare?");
        showChanges();
    }


    public void betError(String errorMessage) {
        betMessageLabel.setText(errorMessage);
        enableBetButton(true);
        enableBetField(true);
        showChanges();
    }


    public void betSuccess() {
        betMessageLabel.setText("");
        showChanges();
    }


    public void setBetMoneyLabel(double d) {
        betMoneyLabel.setText("Saldo: $" + d);
        showChanges();
    }
 

    private void createTurnPanel() {
        JPanel turnPanel = new JPanel(new GridBagLayout());
        turnPanel.setBackground(CARD_TABLE_GREEN);
        GridBagConstraints constraints = new GridBagConstraints();
        JLabel dealerHandLabel = new JLabel("Dealer's Hand:");
        dealerHandLabel.setForeground(TEXT_COLOR);
        dealerHandLabel.setFont(dealerHandLabel.getFont().deriveFont(HANDS_LABEL_SIZE));
        constraints.gridx = 0;
        constraints.gridy = 0;
        turnPanel.add(dealerHandLabel, constraints);
        dealerHandPanel = new JPanel();
        dealerHandPanel.setBackground(CARD_TABLE_GREEN);
        JScrollPane dealerHandScrollPane = new JScrollPane(dealerHandPanel);
        dealerHandScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        dealerHandScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        dealerHandScrollPane.setPreferredSize(DEALER_HAND_PANEL_DIMENSION);
        dealerHandScrollPane.setBorder(BorderFactory.createEmptyBorder());
        constraints.gridy = 1;
        turnPanel.add(dealerHandScrollPane, constraints);
        dealerHandValueLabel = new JLabel();
        dealerHandValueLabel.setForeground(TEXT_COLOR);
        dealerMessageLabel = new JLabel();
        dealerMessageLabel.setForeground(TEXT_COLOR);
        constraints.gridy = 2;
        turnPanel.add(dealerMessageLabel, constraints);
        turnPanel.add(dealerHandValueLabel, constraints);
        JLabel playerHandsLabel = new JLabel("Your Hands:");
        playerHandsLabel.setForeground(TEXT_COLOR);
        playerHandsLabel.setFont(playerHandsLabel.getFont().deriveFont(HANDS_LABEL_SIZE));
        constraints.gridy = 3;
        turnPanel.add(playerHandsLabel, constraints);
        playerHandsPanel = new JPanel();
        playerHandsPanel.setBackground(CARD_TABLE_GREEN);
        JScrollPane playerHandsScrollPane = new JScrollPane(playerHandsPanel);
        playerHandsScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        playerHandsScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        playerHandsScrollPane.setPreferredSize(PLAYER_HANDS_PANEL_DIMENSION);
        playerHandsScrollPane.setBorder(BorderFactory.createEmptyBorder());
        constraints.gridy = 4;
        turnPanel.add(playerHandsScrollPane, constraints);
        messageLabel = new JLabel();
        messageLabel.setForeground(TEXT_COLOR);
        constraints.gridy = 5;
        turnPanel.add(messageLabel, constraints);
        JPanel YesNoButtonPanel = new JPanel();
        YesNoButtonPanel.setBackground(CARD_TABLE_GREEN);
        constraints.gridy = 6;
        turnPanel.add(YesNoButtonPanel, constraints);
        yesButton = new JButton("Yes");
        yesButton.setPreferredSize(BUTTONS_DIMENSION);
        enableYesButton(false);
        constraints.gridy = 6;
        noButton = new JButton("No");
        noButton.setPreferredSize(BUTTONS_DIMENSION);
        enableNoButton(false);
        dealButton = new JButton("Deal");
        dealButton.setPreferredSize(BUTTONS_DIMENSION);
        enableNoButton(false);
        YesNoButtonPanel.add(yesButton);
        YesNoButtonPanel.add(noButton);
        YesNoButtonPanel.add(dealButton);
        blackjackLabel = new JLabel();
        blackjackLabel.setForeground(TEXT_COLOR);
        constraints.gridy = 7;
        turnPanel.add(blackjackLabel, constraints);
        turnMoneyLabel = new JLabel();
        turnMoneyLabel.setForeground(TEXT_COLOR);
        constraints.gridy = 8;
        turnPanel.add(turnMoneyLabel, constraints); 
        add(turnPanel, PanelNames.TURNPANEL.toString());
    }
    
    
    public JLabel getCardImageLabel(String cardName) {
        JLabel cardLabel = null;
        try {
            cardLabel = new JLabel(new ImageIcon(ImageIO.read(getClass().getResourceAsStream("/main/resources/Cards/" + cardName + ".png"))));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return cardLabel;
    }


    public void addDealerHandCard(JLabel cardLabel) {
        dealerHandPanel.add(cardLabel);
        showChanges();
    }
    
    
    public void printDealerHand(DealerImpl dealer) {
    	int a = dealer.getHand().getNumCardsInHand();
    	for(int i = 0; i < a; i++) {
            addDealerHandCard(getCardImageLabel(dealer.getHand().get(i).toString()));
    	}
    }
    
    
    public void printDealerFirstHand(DealerImpl dealer) {
         addDealerHandCard(getCardImageLabel(dealer.getHand().get(0).toString()));
         addDealerHandCard(getCardImageLabel("back"));
    	
    }
    
    
    public void resetDealerHandPanel() {
    	dealerHandPanel.removeAll();
    	showChanges();
    }
    
    
    public void setDealerHandValueLabel(int dealerHandValue) {
        dealerHandValueLabel.setText("Dealer Hand Value: " + dealerHandValue);
        showChanges();
    }
    
    
    public void setDealerMessageLabel(String message) {
        dealerHandValueLabel.setText(message);
        showChanges();
    }
    
 
    public void addPlayerHandPanel(BlackJackGUIHand hand) {
        playerHandsPanel.add(hand);
        showChanges();
    }
    
    
    public void setPlayerHand(BlackJackGUIHand hand, PlayerImpl player) {
    	int a = player.getHand().getNumCardsInHand();
    	for(int i = 0; i < a; i++) {
            hand.addCard(getCardImageLabel(player.getHand().get(i).toString()));
    	}
    }
    
    
    public void showDealPlayer(JLabel cardLabel) {
    	playerHandsPanel.add(cardLabel);
    	showChanges();
    }
    
    
    public void resetPlayerHand(BlackJackGUIHand hand) {
    	hand.reset();
    }
    
    
    public void resetPlayerHandPanel() {
    	playerHandsPanel.removeAll();
    	showChanges();
    }


    public void setTurnMoneyLabel(double d) {
        turnMoneyLabel.setText("Puntata: $" + d);
        showChanges();
    }


    public void setMessageLabel(String message) {
        messageLabel.setText(message);
        showChanges();
    }


    public void enableContinuePlaying() {
        setMessageLabel("Vuoi continuare a giocare?");
        enableYesButton(true);
        enableNoButton(true);
        showChanges();
    }


    public void continuePlayingError() {
        setMessageLabel("ERRORE");
        enableYesButton(true);
        enableNoButton(true);
        showChanges();
    }


    public void setBlackjackLabel(String blackjackMessage) {
        blackjackLabel.setText(blackjackMessage);
        showChanges();
    }


    public void enableBetField(Boolean b) {
        betField.setEnabled(b);
        showChanges();
    }
    
    
    public void enableBetButton(Boolean b) {
        betButton.setEnabled(b);
        betButton.setVisible(b);
        showChanges();
    }
    
    
    public void enableDealButton(Boolean b) {
        dealButton.setEnabled(b);
        dealButton.setVisible(b);
        showChanges();
    }


    public void enableYesButton(Boolean b) {
        yesButton.setEnabled(b);
        yesButton.setVisible(b);
        showChanges();
    }
    

    public void enableNoButton(Boolean b) {
        noButton.setEnabled(b);
        noButton.setVisible(b);
        showChanges();
    }
    
    
    private void enableStartButton(Boolean b) {
        playButton.setEnabled(b);
        playButton.setVisible(b);
        exitButton.setEnabled(b);
        exitButton.setVisible(b);
        showChanges();
    }
    
    
    
    public void printDealCard() {
    	addDealerHandCard(getCardImageLabel("back"));
    	addDealerHandCard(getCardImageLabel("back"));
    	showDealPlayer(getCardImageLabel("back"));
    	showDealPlayer(getCardImageLabel("back"));
    }
    
    
    private void createContinuePlayingPanel() {
        JPanel continuePlayingPanel = new JPanel(new GridBagLayout());
        continuePlayingPanel.setBackground(CARD_TABLE_GREEN);
        GridBagConstraints constraints = new GridBagConstraints();
        continuePlayingMessageLabel = new JLabel();
        continuePlayingMessageLabel.setForeground(TEXT_COLOR);
        constraints.gridx = 0;
        constraints.gridy = 0;
        continuePlayingPanel.add(continuePlayingMessageLabel, constraints);
        add(continuePlayingPanel, PanelNames.CONTINUEPLAYINGPANEL.toString());
    }


    public void gameOver() {
        continuePlayingMessageLabel.setText("GAME OVER! Grazie per aver giocato!");
        showChanges();
    }
    
    
    private void showPanel(PanelNames panelName) {
        CardLayout cardLayout = (CardLayout) getContentPane().getLayout();
        cardLayout.show(getContentPane(), panelName.toString());
        showChanges();
    }


    public void showWelcomePanel(String name) {
    	nameLabel.setText(name);
        showChanges();
        showPanel(PanelNames.WELCOMEPANEL);
    }
    
    
    public void showStartPanel() {
        showPanel(PanelNames.STARTPANEL);
    	enableStartButton(true);
    }


    public void showBetPanel() {
        showPanel(PanelNames.BETPANEL);
    }


    public void showTurnPanel() {
        showPanel(PanelNames.TURNPANEL);
    }


    public void showContinuePlayingPanel() {
        showPanel(PanelNames.CONTINUEPLAYINGPANEL);
    }
   

    public void reset() {
        createPanels();
        setupActionListeners();
        showContinuePlayingPanel();
    }
   
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object target = e.getSource();;
        
        if(target == playButton) {
        	controller.getMessage(playButton.getText());
        	controller.GetStart();
        	enableStartButton(false);
        	
        }else if(target == exitButton) {        
        	System.exit(0);
        	enableDealButton(false);
        	
        } else if(target == dealButton) { 
        	controller.playGame();
        	enableDealButton(false);
        	
        }else if (target == betField || target == betButton) {
        	controller.getMessage(betField.getText());
        	controller.getBet();
        	controller.checkBet();
        	
        }else if (target == yesButton) {
        	controller.setGame();
            enableYesButton(false);
            enableNoButton(false);
            
        } else if (target == noButton) {
            System.exit(0);
            enableYesButton(false);
            enableNoButton(false);
        }
    
    }
}
