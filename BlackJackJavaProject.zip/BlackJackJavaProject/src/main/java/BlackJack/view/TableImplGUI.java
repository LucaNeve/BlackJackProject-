package main.java.BlackJack.view;

import main.java.BlackJack.model.DealerImpl;
import main.java.BlackJack.model.Hand;
import main.java.BlackJack.model.PlayerImpl;
import main.java.BlackJack.model.Shoe;

public class TableImplGUI{
    private static final int AMOUNT = 1000;
    private static final int NUM_DECK = 4;
    private final String playerName;
    private Shoe shoe;
    protected PlayerImpl player;
    private PlayerImpl playerSplit;
    private DealerImpl dealer;
    private BlackJackGUIView view;
    protected BlackJackGUIHand hand;
    private BlackJackGUIHand splithand;
    private boolean gameOver;
    private boolean playerDone;
    private boolean dealerDone;
    private boolean haveSplitted;
    private boolean splitDone;
	
    TableImplGUI(String playerName, BlackJackGUIView view, BlackJackGUIHand hand, BlackJackGUIHand splithand) {
    	
        this.playerName = playerName;
        this.view = view;
        this.hand = hand;
        this.splithand = splithand;
        this.gameOver = false;

        // Creo la shoe
        this.shoe = new Shoe(NUM_DECK);

        // Creo il player e la sua mano
        this.player = new PlayerImpl(this.playerName, AMOUNT, new Hand());

        // Creo il player e la sua mano in caso di split
        this.playerSplit = new PlayerImpl(this.playerName + "Split", this.player.getBet(), new Hand());

        // Creo il dealer e la sua mano
        this.dealer = new DealerImpl(new Hand());

    }
    
    
    public boolean isPlayerDone() {
        return (!this.playerDone);
    }
    

    public boolean haveSplit() {
        return this.haveSplitted;
    }
    

    public boolean isSplitDone() {
        return this.splitDone;
    }
    

    public boolean isAmountOver() {
        if (this.player.getAmount() == 0) {
            this.gameOver = true;
        }
        return gameOver;
    }
    

    public boolean checkBetLimit(int bet) {
        return bet > this.player.getAmount();
    }
    

    public void bet(int bet) {
        this.player.setBet(bet);
        this.player.setAmount(-(bet));
    }
    
    
    public void checkLimit() {
        if (this.playerSplit.getHand().getHandValue() > 21) {
        	splithand.bust();
        	this.splitDone = true;
        }
        if (this.player.getHand().getHandValue() > 21) {
            this.hand.bust();
            this.playerDone = true;
            if(this.haveSplitted == false)
                this.dealerDone = true;
       
        }
    } 
    
            
    public void setGameOver() {
        this.gameOver = true;
    }
    
    
    public void checkShoe() {
        this.shoe.checkShoe();
    }
    
    
	public boolean isGameOver() {
        if (this.player.getAmount() == 0) {
            this.gameOver = true;
        }
        return gameOver;
    }
	
    
    public void printPlayerAmount() {
        view.setTurnMoneyLabel(this.player.getAmount());
    }
    
    
    public void resetAllHands() {
        this.player.getHand().resetHand();
        this.playerSplit.getHand().resetHand();
        this.dealer.getHand().resetHand();
    }
    
    
    public void startGame() {
    	
        this.playerDone = false;
        this.dealerDone = false;
        this.haveSplitted = false;
        this.splitDone = true;
        
        this.player.setHand(shoe);
        this.dealer.setHand(shoe);

        this.showDealerFirstHand(dealer);
        this.showPlayerHand(hand, player);
        
    }
    
    
    public void shiftManagment() {
    	if (this.player.getHand().getHandValue() == 21 && this.splitDone == true) {
            this.playerDone = true;
        }

        if (this.splitDone == false && this.playerSplit.getHand().getHandValue() == 21)
            this.splitDone = true;

        this.controlSplit();
    }
    
    
    public void controlSplit() {
        if (!this.playerDone) {
            if (this.splitDone == false) {
            	view.setMessageLabel("Tocca alla mano splittata");
                this.playerPlay(splithand);
            } else {
            	view.setMessageLabel("Tocca al player");
                this.playerPlay(hand);
            }
        }
    }
    
    
    public void dealerPlay() {
    	this.resetDealerHand();
        if (!this.dealerDone) {
            view.setMessageLabel("Tocca al dealer!");
            this.dealer.play(shoe);
            this.dealerDone = true;
            showDealerHand(dealer);
        }
    }
    
    
    public void checkBlackJack() {
        if (this.player.getHand().checkBlackJack()) {
            this.player.setAmount((this.player.getBet() / 2) + this.player.getBet());
            hand.setHandMessageLabel("Hai fatto BlackJack");
            if(this.haveSplitted == false) {
            	this.playerDone = true;
            }
        }

        if (this.splitDone == false) {
            if (this.playerSplit.getHand().checkBlackJack()) {
                this.player.setAmount((this.player.getBet() / 2) + this.player.getBet());
                splithand.setHandMessageLabel("Hai fatto BlackJack nella mano splittata!!!");
                this.splitDone = true;
            }
        }
    }
    
    
    public void playerPlay(BlackJackGUIHand h) {

        this.checkBlackJack();

        if (this.splitDone == false) {
            splithand.setHandMessageLabel("Gioca la prima mano");
        } else {
            if (this.haveSplitted == true) {
                splithand.setHandMessageLabel("");
                hand.setHandMessageLabel("Gioca la seconda mano");
            }
        }
		
	}
    
    
    public void hitPlay() {
    	if(this.haveSplitted == true) {
    		if(this.splitDone == false) {
    	        this.resetPlayerHand(splithand);
    	        this.playerSplit.hit(shoe);
    	        this.showPlayerHand(splithand, playerSplit);
    		}else if(this.splitDone == true) {
    	        this.resetPlayerHand(hand);
    	        this.player.hit(shoe);
    	        this.showPlayerHand(hand, player);
    		}
    	}else if(this.haveSplitted == false) {
            this.resetPlayerHand(hand);
            this.player.hit(shoe);
            this.showPlayerHand(hand, player);
    	}

    	this.checkLimit();
    }
    
    
    public void doubleDownPlay() {
    	if(this.haveSplitted == true) {
    		if(this.splitDone == false) {
    	    	this.resetPlayerHand(splithand);
    	        this.playerSplit.doubleDown(this.player.getBet(), shoe);
    	        this.showPlayerHand(splithand, playerSplit);
    	        
    		}else if(this.splitDone == true) {
    	    	this.resetPlayerHand(hand);
    	        this.player.doubleDown(this.player.getBet(), shoe);
    	        this.showPlayerHand(hand, player);
    		}
    	}else if(this.haveSplitted == false) {
	    	this.resetPlayerHand(hand);
	        this.player.doubleDown(this.player.getBet(), shoe);
	        this.showPlayerHand(hand, player);
    	}
        this.checkLimit();
        if (this.splitDone == false) {
            this.splitDone = true;
        } else
            this.playerDone = true;
        this.hand.doubleDownSuccess();
    }
    
    
    public boolean isDoubleDownPossible() {
        return (this.player.getAmount() - this.player.getBet()) >= 0;
    }
    
    
    public boolean DoubleDownButton() {
    	boolean b;
    	if(player.getHand().getNumCardsInHand() == 2) {
    		b = true;
    	}else {
    		b = false;
    	}
    	return b;
    }
    
    
    public void splitPlay() {
    	this.resetPlayerHand(hand);
    	this.resetPlayerSplitHand(splithand);
        this.playerSplit.getHand().add(player.getHand().getFirstCard());
        this.player.getHand().removeFirstCard();
        this.player.hit(shoe);
        this.playerSplit.hit(shoe);
        this.splitDone = false;
        this.haveSplitted = true;
        this.player.setAmount(-(this.player.getBet()));
        this.showPlayerHand(hand, player);
        this.showPlayerHand(splithand, playerSplit);
    }
    
    
    public boolean isSplitPossible() {
        return this.player.getHand().splitPossible() && this.haveSplitted == false
                && (this.player.getAmount() - this.player.getBet()) >= 0;
    }
    
    
    public void resetPlayerSplitHand(BlackJackGUIHand hand) {
    	view.resetPlayerHand(hand);
    }
    
    
    public void stayPlay() {
        if (this.splitDone == false) {
            this.splitDone = true;
        } else
            this.playerDone = true;
    }
    
    
    public void showPlayerHand(BlackJackGUIHand hand, PlayerImpl player) {
    	hand.setHandValueLabel(player.getHand().getHandValue());
    	view.setPlayerHand(hand, player);
    	view.addPlayerHandPanel(hand);
    }
    
    
    public void resetPlayerHand(BlackJackGUIHand hand) {
    	view.resetPlayerHand(hand);
    }
    
    
    public void resetDealerHand() {
    	view.resetDealerHandPanel();
    }
    
    
    public void resetPlayerHand() {
    	view.resetPlayerHandPanel();
    }
    
    
    public void showDeal() {
    	view.printDealCard();
    }
       
    
    public void showDealerHand(DealerImpl dealer) {
    	view.setDealerHandValueLabel(dealer.getHand().getHandValue());
    	view.printDealerHand(dealer);
    }
    
    
    public void showDealerFirstHand(DealerImpl dealer) {
    	view.printDealerFirstHand(dealer);
    }
    
    
    public void enableHitStandButton() {
    	hand.enableHitStand();
    }
    
    
    public void enableDoubleDownButton() {
    	hand.enableDoubleDown();
    }
    
    
    public void disableDoubleDownButton() {
    	hand.disableDoubleDown();
    }
    
    
    public void enableSplitButton() {
    	hand.enableSplit();
    }
    
    
    public void disableSplitButton() {
    	splithand.disableSplit();
    }
    
    
    public void enableSplitHitStandButton() {
    	splithand.enableHitStand();
    }
    
    
    public void enableSplitDoubleDownButton() {
    	splithand.enableDoubleDown();
    }
    
    
    public void disableSplitDoubleDownButton() {
    	splithand.disableDoubleDown();
    }
    
    
    public void enableSplitSplitButton() {
    	splithand.enableSplit();
    }
    
    
    public void disableSplitSplitButton() {
    	splithand.disableSplit();
    }
    
    
    public void disableHandButton() {
    	hand.enableHitButton(false);
    	hand.enableStayButton(false);
    	hand.enableSplitButton(false);
    	hand.enableDoubleDownButton(false);
    }
    
    
    public void disableSplitHandButton() {
        splithand.enableHitButton(false);
        splithand.enableStayButton(false);
        splithand.enableSplitButton(false);
        splithand.enableDoubleDownButton(false);
    }
    
    
    public void decideWinner() {
        if (this.haveSplitted == true) {
            if ((this.playerSplit.getHand().getHandValue() > this.dealer.getHand().getHandValue()
                    && this.playerSplit.getHand().getHandValue() <= 21) ||
                    (this.playerSplit.getHand().getHandValue() <= 21 && this.dealer.getHand().getHandValue() > 21)) {

                splithand.setHandMessageLabel("HAI VINTO NELLA PRIMA MANO");
                this.player.setAmount(this.player.getBet() * 2);

            } else if (this.playerSplit.getHand().getHandValue() == this.dealer.getHand().getHandValue()) {

                splithand.setHandMessageLabel("PAREGGIO NELLA PRIMA MANO");
                this.player.setAmount(this.player.getBet());

            } else {
                splithand.setHandMessageLabel("HAI PERSO NELLA PRIMA MANO");
            }
            
            if ((this.player.getHand().getHandValue() > this.dealer.getHand().getHandValue()
                    && this.player.getHand().getHandValue() <= 21) ||
                    (this.player.getHand().getHandValue() <= 21 && this.dealer.getHand().getHandValue() > 21)) {

                hand.setHandMessageLabel("HAI VINTO NELLA SECONDA MANO");
                this.player.setAmount(this.player.getBet() * 2);

            } else if (this.player.getHand().getHandValue() == this.dealer.getHand().getHandValue()) {

                hand.setHandMessageLabel("PAREGGIO NELLA SECONDA MANO");
                this.player.setAmount(this.player.getBet());

            } else {
                hand.setHandMessageLabel("HAI PERSO NELLA SECONDA MANO");
            }

        } else {

            if ((this.player.getHand().getHandValue() > this.dealer.getHand().getHandValue()
                    && this.player.getHand().getHandValue() <= 21) ||
                    (this.player.getHand().getHandValue() <= 21 && this.dealer.getHand().getHandValue() > 21)) {

            	hand.setHandMessageLabel("HAI VINTO");
                this.player.setAmount(this.player.getBet() * 2);

            } else if (this.player.getHand().getHandValue() == this.dealer.getHand().getHandValue()) {
            	hand.setHandMessageLabel("HAI PAREGGIATO");
                this.player.setAmount(this.player.getBet());
            } else {
            	hand.setHandMessageLabel("HAI PERSO");
            }
        }
    }    

}
