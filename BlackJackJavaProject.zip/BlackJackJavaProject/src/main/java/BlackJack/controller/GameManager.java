package main.java.BlackJack.controller;


public interface GameManager {

    // Inizializza il gioco facendo inserire il nome del giocatore e permettendo di
    // selezionare la modalità di gioco
    public void setUpGame();

    // Gestisce l'inserimento dei bot da parte dell'utente
    public void botSetUp();

    // Permette di scegliere all'utente di cominciare a giocare oppure di uscire
    // dalla partita
    public void setGame();

    // Gestisce l'inserimento delle puntate da parte dell'utente
    public void bet();

    // Controlla che gli input inseriti dall'utente al momento della puntata siano
    // corretti
    public void checkBet(int bet);

    // Metodo che gestisce il flusso del gioco chiamando metodi specifici per lo
    // sviluppo ordinato della partita
    public void playGame();

    // Permette all'utente di decidere se ricominciare a giocare in un nuovo tavolo
    // oppure di uscire definitivamente dal gioco
    public void resetGame();

    // Gestisce e controlla tutti gli input inseriti dall'utente al momento di
    // selezionare la giocata da effettuare
    public void playControl();
}
