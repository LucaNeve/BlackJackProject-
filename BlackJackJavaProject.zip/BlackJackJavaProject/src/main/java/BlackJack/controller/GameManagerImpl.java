package main.java.BlackJack.controller;

import java.util.*;

//import main.java.BlackJack.model.Table;
import main.java.BlackJack.model.TableImpl;
import main.java.BlackJack.view.GameManagerGUI;

public class GameManagerImpl implements GameManager {
    private TableImpl table;
    private Scanner scanner;
    private String choice;
    private String playerName;
    //private GameManagerGUI game;
    private int nBot;

    public GameManagerImpl() {
        this.scanner = new Scanner(System.in);
        this.setUpGame();
    }

    public TableImpl getTable() {
        return this.table;
    }

    public void setUpGame() {
        System.out.println("Benvenuto al BlackJack!\nInserisci il tuo nome:");
        this.playerName = scanner.nextLine();
        
        System.out.println("Vuoi giocare da terminale o da interfaccia grafica?\n'T'-> Terminale\n'I'-> Interfaccia Grafica (only Singleplayer use)");
        this.choice = scanner.nextLine();
        
        if (this.choice.equalsIgnoreCase("I")) {
            /*this.game = */new GameManagerGUI(playerName);
        } else if (this.choice.equalsIgnoreCase("T")) {
            this.TerminalGame();
        } else {
            System.out.println("Scelta non valida, inserisci la lettera giusta!");
            setUpGame();
        }
    }
        
        
    public void TerminalGame() {
    	
        System.out.println("In che modalità vuoi giocare?\n'S'-> Singleplayer\n'M'-> Multiplayer");
        this.choice = scanner.nextLine();
        if (this.choice.equalsIgnoreCase("S")) {
            this.table = new TableImpl(playerName, 0);
        } else if (this.choice.equalsIgnoreCase("M")) {
            this.botSetUp();
            this.table = new TableImpl(playerName, nBot);
        } else {
            System.out.println("Scelta non valida, inserisci la lettera giusta!");
            setUpGame();
        }
        this.setGame();
    }
    

    public void botSetUp() {
        System.out.println("Inserisci il numero di Bot (1-4):");
        try {
            this.nBot = Integer.parseInt(scanner.nextLine());
            if (this.nBot > 4 || this.nBot <= 0) {
                System.out.println("Inserisci nuovamente il numero di bot!");
                this.botSetUp();
            }
        } catch (NumberFormatException e) {
            System.out.println("Valore inserito non corretto, inserisci un numero compreso tra 1 e 4!");
            this.botSetUp();
        }
    }

    public void setGame() {
        this.table.resetAllHands();
        while (!this.table.isAmountOver()) {
            System.out.println("\nINIZIARE A GIOCARE?");
            System.out.println("'H' -> Gioca \n'E' -> Esci \n");
            this.choice = scanner.nextLine();

            if (this.choice.equalsIgnoreCase("H")) {
                System.out.println("\n" + this.playerName);
                this.table.printPlayerAmount();
                this.bet();
            } else if (this.choice.equalsIgnoreCase("E")) {
                this.table.setGameOver();
            } else if ((!this.choice.equalsIgnoreCase("H")) && (!this.choice.equalsIgnoreCase("E"))) {
                this.setGame();
            }
        }
        System.out.println("\n" + this.playerName + ", Giocata finita\n");
        this.resetGame();

    }

    public void bet() {
        System.out.println("Quanto vuoi puntare?\n");

        try {
            int bet = Integer.parseInt(scanner.nextLine());
            this.checkBet(bet);
            this.table.bet(bet);
            this.playGame();
        } catch (NumberFormatException e) {
            System.out.println("\nValore inserito non valido, inserire un valore numerico intero!\n");
            this.bet();
        }
    }

    public void checkBet(int bet) {
        if (bet <= 0) {
            System.out.println("\nLa puntata deve essere >= 0!");
            this.bet();
        } else if (this.table.checkBetLimit(bet)) {
            System.out.println("\nHai puntato troppo!\n");
            this.table.printPlayerAmount();
            this.bet();
        }
    }

    public void playGame() {
        this.table.startGame();
        while (this.table.controlShift()) {
            this.playControl();
            this.table.controlSplitShift();
        }
        this.table.botPlay();
        this.table.dealerPlay();
        this.table.decideWinner();
        this.table.checkShoe();
        this.setGame();
    }

    public void resetGame() {
        System.out.println("\n'Y' -> Nuovo Tavolo \n'N' -> Esci \n");
        this.choice = scanner.nextLine();
        if (choice.equalsIgnoreCase("Y")) {
            this.table.resetAllHands();
            this.setUpGame();
        } else if (this.choice.equalsIgnoreCase("N")) {
            System.exit(0);
        } else if ((!this.choice.equalsIgnoreCase("Y")) && (!this.choice.equalsIgnoreCase("N"))) {
            System.out.println("Inserisci la lettera corretta!");
            this.resetGame();
        }

    }

    public void playControl() {
        System.out.print("\nDigita:\n- H -> Hit \n- S -> Stay \n");
        if (this.table.isDoubleDownPossible()) {
            System.out.println("- D -> DoubleDown");
        }
        if (this.table.isSplitPossible()) {
            System.out.println("- X -> Split\n");
        }
        this.choice = scanner.nextLine();

        if (this.choice.equalsIgnoreCase("H")) {
            this.table.hitPlay();
        } else if (this.choice.equalsIgnoreCase("S")) {
            this.table.stayPlay();
        } else if (this.choice.equalsIgnoreCase("D")) {
            this.table.doubleDownPlay();
        } else if (this.choice.equalsIgnoreCase("X")) {
            this.table.splitPlay();
        }

        if ((!this.choice.equalsIgnoreCase("H")) && (!this.choice.equalsIgnoreCase("S"))
                && (!this.choice.equalsIgnoreCase("D")) && (!this.choice.equalsIgnoreCase("X"))) {
            System.out.println(
                    "\nLa giocata selezionata non è corretta, inserire nuovamente la giocata da effettuare!\n");
            this.playControl();
        }
    }
    
}