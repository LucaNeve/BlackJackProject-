/*import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class BlackjackGameTest{

    private TableImpl table;
    private Shoe shoe;

    @Before
    public void setUp() {
        shoe = new Shoe(4);
        table = new TableImpl("TestPlayer", 0);
    }

    @Test
    public void testBet() {
        table.bet(50);
        assertEquals(950, table.getPlayer().getAmount(), 0.01);
    }

    @Test
    public void testShoe(){
        assertEquals(208,shoe.numCardInShoe());
    }

    @Test
    public void testCheckBetLimit() {
        assertFalse(table.checkBetLimit(1000));
        assertTrue(table.checkBetLimit(1050));
    }

    @Test
    public void testHandValueCalculation() {
        Hand hand = new Hand();
        hand.add(new Card(Card.Rank.Ten, Card.Suit.Hearts));
        hand.add(new Card(Card.Rank.Ace, Card.Suit.Clubs));
        assertEquals(21, hand.getHandValue());
    }

    @Test
    public void testBlackjack() {
        Hand hand = new Hand();
        hand.add(new Card(Card.Rank.Ace, Card.Suit.Clubs));
        hand.add(new Card(Card.Rank.King, Card.Suit.Diamonds));
        hand.getHandValue();
        assertTrue(hand.checkBlackJack());
    }

    @Test
    public void testPlayerHit() {
        table.bet(100);
        table.setHandAndBoolean();
        table.playerPlay(table.getPlayer());
        int initialHandValue = table.getPlayer().getHand().getHandValue();
        int initialNumCardsInHand = table.getPlayer().getHand().getNumCardsInHand();
        table.hitPlay();
        int updatedHandValue = table.getPlayer().getHand().getHandValue();
        int updateNumCardsInHand = table.getPlayer().getHand().getNumCardsInHand();
        assertTrue(updatedHandValue > initialHandValue);
        assertTrue(updateNumCardsInHand > initialNumCardsInHand);
    }

    @Test
    public void testPlayerStay() {
        table.bet(100);
        table.setHandAndBoolean();
        table.playerPlay(table.getPlayer());
        table.stayPlay();
        assertTrue(table.isPlayerDone());
    }

    @Test
    public void testSplit() {
        table.bet(100);
        table.setHandAndBoolean();
        table.splitPlay();
        assertEquals(2, table.getPlayer().getHand().getNumCardsInHand());
        assertEquals(2, table.getPlayerSplit().getHand().getNumCardsInHand());
        assertTrue(table.haveSplit());
        assertFalse(table.isSplitDone());
    }

    @Test
    public void testDoubleDown() {
        table.bet(100);
        table.setHandAndBoolean();
        table.playerPlay(table.getPlayer());
        table.doubleDownPlay();
        assertEquals(200, table.getPlayer().getBet(), 0.01);
        assertEquals(800, table.getPlayer().getAmount(), 0.01);
    }

    @Test
    public void testBotsPlay() {
        int nBots = 3;
        table = new TableImpl("TestPlayer", nBots);
        table.setHandAndBoolean();
        assertFalse(table.isBotsDone());
        table.botPlay();
        assertTrue(table.isBotsDone());
    }

    @Test
    public void testDealerPlay() {
        table.setHandAndBoolean();
        assertFalse(table.isDealerDone());
        table.dealerPlay();
        assertTrue(table.isDealerDone());
    }

    @Test
    public void testDecideWinner() {
        table.bet(100);
        Hand playerHand = new Hand();
        playerHand.add(new Card(Card.Rank.Ten, Card.Suit.Hearts));
        playerHand.add(new Card(Card.Rank.Eight, Card.Suit.Diamonds));
        table.getPlayer().setHandCards(playerHand);

        Hand dealerHand = new Hand();
        dealerHand.add(new Card(Card.Rank.Ten, Card.Suit.Clubs));
        dealerHand.add(new Card(Card.Rank.Seven, Card.Suit.Spades));
        table.getDealer().setHandCards(dealerHand);

        table.decideWinner();
        assertTrue(table.isPlayerWin());
        table.resetAllHands();

        Hand playerHand1 = new Hand();
        playerHand1.add(new Card(Card.Rank.Ten, Card.Suit.Hearts));
        playerHand1.add(new Card(Card.Rank.Queen, Card.Suit.Diamonds));
        table.getPlayer().setHandCards(playerHand1);

        Hand dealerHand1 = new Hand();
        dealerHand1.add(new Card(Card.Rank.Ten, Card.Suit.Clubs));
        dealerHand1.add(new Card(Card.Rank.Ace, Card.Suit.Spades));
        table.getDealer().setHandCards(dealerHand1);

        table.decideWinner();
        assertFalse(table.isPlayerWin());
        table.resetAllHands();

        Hand playerHand2 = new Hand();
        playerHand2.add(new Card(Card.Rank.Nine, Card.Suit.Hearts));
        playerHand2.add(new Card(Card.Rank.Five, Card.Suit.Diamonds));
        table.getPlayer().setHandCards(playerHand2);

        Hand dealerHand2 = new Hand();
        dealerHand2.add(new Card(Card.Rank.Ten, Card.Suit.Clubs));
        dealerHand2.add(new Card(Card.Rank.Four, Card.Suit.Spades));
        table.getDealer().setHandCards(dealerHand2);

        table.decideWinner();
        assertTrue(table.isTie());
    }
}*/
