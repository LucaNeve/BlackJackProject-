import main.java.BlackJack.controller.GameManagerImpl;

public class Main {
    public static void main(String[] args) {
        new GameManagerImpl();
    }
}
